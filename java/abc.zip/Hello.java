public class Hello{
public static void main(String args[]){
int x=129;
byte y=(byte)x;
System.out.println(y);
}}