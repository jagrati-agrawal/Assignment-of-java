import java.util.Scanner;
public class GreatestInt{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
if(a>b){
System.out.println("the greatest integer is "+a);}
else{
System.out.println("the greastest integer is "+b);
}
}}

