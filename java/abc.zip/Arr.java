class Arr {
	public static void main(String[] args){
		//int[] A;
		//A = new int[5];
		int[][] A;
		A=new int[2][2];
		A[0][0]=56;
		A[0][1]=45;
		A[1][0]=34;
		A[1][1]=45;

		System.out.println(Array.toString(A));

	}}