import java.util.Scanner;
class Test {
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int arr[]=[1,23,45,12,90];
		int ans=0;
		int index=0;	
		while(i<arr.length){
			if(arr>ans){
				ans=arr[i];
				index=i;}
		i++;}
		System.out.println(ans)


		
		/*byte x=10;
		switch(x+1){
		case 10:
			System.out.println("case-1");
			break;
		case 20:
			System.out.println("case-2");
			break;
		case 300:
			System.out.println("case-3");
			break;
		default:
			System.out.println("default");*/


		}

		/*int hour=sc.nextInt();
		float rate=sc.nextfloat();
		int h;
		double pay;
		if (hour<=8){
			pay=hour*rate;
			System .out.println(pay);}
		else if(hour>8){
			h=hour-8;
			pay=h*(0.5f*rate)+(8*rate);
			System.out.println(pay);}*/


}}


		
		
	