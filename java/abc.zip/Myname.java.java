public class MYname{
public static void main(String args[]){
System.out.println("test case passed");
}}