import java.util.Scanner;
public class Absolute{
public static void main(String[] args){
Scanner sc = new Scanner(System.in);
int a=sc.nextInt();
if(a<0){
System.out.println("the absolute value is  "+(-1*a));
}
else{
System.out.println("the absolute value is  "+a);}
}}
