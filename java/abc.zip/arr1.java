
/*import java.util.Scanner;
class arr1{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);

int []arr1={1,2,3,4};

int []arr2=new int[arr1.length];
for(int i=0;i<arr1.length;i++){
arr2[i]=arr1[i];
}
arr1=new int[arr2.length + 1];
for(int i=0;i<arr2.length;i++){
arr1[i]=arr2[i]; }
arr1[arr2.length]=33;
System.out.println(arr1);

}}*/

import java.util.Scanner;
class Arr{
public static void main(String[] args){
int[] arr1={1,3,2,4};
int i,ele;
Scanner sc=new Scanner(System.in);
ele=sc.nextInt();
i=sc.nextInt();
for( i=0;i<=arr1.length;i++){


}
}}